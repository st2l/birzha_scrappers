import requests

# URL of the site to which you want to send the POST request
url = 'http://localhost:64783/event'  # This is a test URL that echoes back the data you send

# Data to be sent in the POST request
data = {
    'message': 'Hello, this is a test message!'
}

# Sending the POST request
response = requests.post(url, json=data)

# Checking the response
if response.status_code == 200:
    print('Success!')
    print('Response JSON:', response.json())  # Print the JSON response
else:                               
    print('Failed to send POST request. Status code:', response.status_code)