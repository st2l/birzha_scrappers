class KworkException(Exception):
    pass


class KworkBotException(Exception):
    pass
